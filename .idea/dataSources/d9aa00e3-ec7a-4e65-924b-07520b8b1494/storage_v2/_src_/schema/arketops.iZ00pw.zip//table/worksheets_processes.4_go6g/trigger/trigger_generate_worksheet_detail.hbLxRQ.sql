CREATE DEFINER = root@localhost TRIGGER trigger_generate_worksheet_detail
    AFTER INSERT
    ON worksheets_processes
    FOR EACH ROW
BEGIN
    DECLARE id_subprocess INT;
    DECLARE id_subprocess_previous INT DEFAULT 0;
    DECLARE err BOOLEAN DEFAULT FALSE;
    DECLARE cursor_subprocesses_by_process CURSOR FOR SELECT s.id_subprocess
                                                      FROM subprocesses s
                                                      WHERE s.id_process = new.id_process
                                                        AND s.active = 'S';

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET err = TRUE;
    OPEN cursor_subprocesses_by_process;
    cursor_subprocesses_by_process_loop:
    LOOP
        FETCH cursor_subprocesses_by_process INTO id_subprocess;
        IF id_subprocess = id_subprocess_previous THEN
            LEAVE cursor_subprocesses_by_process_loop;
        ELSE
            INSERT INTO worksheets_details(id_worksheet_process, id_subprocess) VALUES (new.id_worksheet_process, id_subprocess);
            SET id_subprocess_previous = id_subprocess;
            IF err = TRUE THEN
                LEAVE cursor_subprocesses_by_process_loop;
            END IF;
        END IF;
    END LOOP;
    CLOSE cursor_subprocesses_by_process;
END;

